package vo;

import java.sql.Date;

public class ReBoard {
	private int BOARD_NUM;
	private int REBOARD_NUM;
	private String REBOARD_NAME;
	private String REBOARD_PASS;
	private String REBOARD_CONTENT;
	private int REBOARD_RE_REF;
	private int REBOARD_RE_SEQ;
	private Date REBOARD_DATE;
	
	public int getBOARD_NUM() {
		return BOARD_NUM;
	}
	public void setBOARD_NUM(int bOARD_NUM) {
		BOARD_NUM = bOARD_NUM;
	}
	public int getREBOARD_NUM() {
		return REBOARD_NUM;
	}
	public void setREBOARD_NUM(int rEBOARD_NUM) {
		REBOARD_NUM = rEBOARD_NUM;
	}
	public String getREBOARD_NAME() {
		return REBOARD_NAME;
	}
	public void setREBOARD_NAME(String rEBOARD_NAME) {
		REBOARD_NAME = rEBOARD_NAME;
	}
	public String getREBOARD_PASS() {
		return REBOARD_PASS;
	}
	public void setREBOARD_PASS(String rEBOARD_PASS) {
		REBOARD_PASS = rEBOARD_PASS;
	}
	public String getREBOARD_CONTENT() {
		return REBOARD_CONTENT;
	}
	public void setREBOARD_CONTENT(String rEBOARD_CONTENT) {
		REBOARD_CONTENT = rEBOARD_CONTENT;
	}
	public int getREBOARD_RE_REF() {
		return REBOARD_RE_REF;
	}
	public void setREBOARD_RE_REF(int rEBOARD_RE_REF) {
		REBOARD_RE_REF = rEBOARD_RE_REF;
	}
	public int getREBOARD_RE_SEQ() {
		return REBOARD_RE_SEQ;
	}
	public void setREBOARD_RE_SEQ(int rEBOARD_RE_SEQ) {
		REBOARD_RE_SEQ = rEBOARD_RE_SEQ;
	}
	public Date getREBOARD_DATE() {
		return REBOARD_DATE;
	}
	public void setREBOARD_DATE(Date bOARD_DATE) {
		REBOARD_DATE = bOARD_DATE;
	}
	
	
	
}

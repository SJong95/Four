package vo;

import java.sql.Date;
public class Board {
	private int BOARD_NUM;
	private String BOARD_LINK;
	private String BOARD_LINK_VIDEO;
	private String BOARD_LINK_TITLE;
	private String BOARD_LINK_IMAGE;
	private String BOARD_LINK_NAME;
	private String BOARD_NAME;
	private String BOARD_PASS;
	private String BOARD_SUBJECT;
	private String BOARD_CONTENT;
	private String BOARD_CATEGORY;
	private Date BOARD_DATE;
	private int BOARD_LIKE;
	private int BOARD_REPORT;
	public int getBOARD_NUM() {
		return BOARD_NUM;
	}
	public void setBOARD_NUM(int bOARD_NUM) {
		BOARD_NUM = bOARD_NUM;
	}
	public String getBOARD_LINK() {
		return BOARD_LINK;
	}
	public void setBOARD_LINK(String bOARD_LINK) {
		BOARD_LINK = bOARD_LINK;
	}
	public String getBOARD_LINK_VIDEO() {
		return BOARD_LINK_VIDEO;
	}
	public void setBOARD_LINK_VIDEO(String bOARD_LINK_VIDEO) {
		BOARD_LINK_VIDEO = bOARD_LINK_VIDEO;
	}
	public String getBOARD_LINK_TITLE() {
		return BOARD_LINK_TITLE;
	}
	public void setBOARD_LINK_TITLE(String bOARD_LINK_TITLE) {
		BOARD_LINK_TITLE = bOARD_LINK_TITLE;
	}
	public String getBOARD_LINK_IMAGE() {
		return BOARD_LINK_IMAGE;
	}
	public void setBOARD_LINK_IMAGE(String bOARD_LINK_IMAGE) {
		BOARD_LINK_IMAGE = bOARD_LINK_IMAGE;
	}
	public String getBOARD_LINK_NAME() {
		return BOARD_LINK_NAME;
	}
	public void setBOARD_LINK_NAME(String bOARD_LINK_NAME) {
		BOARD_LINK_NAME = bOARD_LINK_NAME;
	}
	public String getBOARD_NAME() {
		return BOARD_NAME;
	}
	public void setBOARD_NAME(String bOARD_NAME) {
		BOARD_NAME = bOARD_NAME;
	}
	public String getBOARD_PASS() {
		return BOARD_PASS;
	}
	public void setBOARD_PASS(String bOARD_PASS) {
		BOARD_PASS = bOARD_PASS;
	}
	public String getBOARD_SUBJECT() {
		return BOARD_SUBJECT;
	}
	public void setBOARD_SUBJECT(String bOARD_SUBJECT) {
		BOARD_SUBJECT = bOARD_SUBJECT;
	}
	public String getBOARD_CONTENT() {
		return BOARD_CONTENT;
	}
	public void setBOARD_CONTENT(String bOARD_CONTENT) {
		BOARD_CONTENT = bOARD_CONTENT;
	}
	public String getBOARD_CATEGORY() {
		return BOARD_CATEGORY;
	}
	public void setBOARD_CATEGORY(String bOARD_CATEGORY) {
		BOARD_CATEGORY = bOARD_CATEGORY;
	}
	public Date getBOARD_DATE() {
		return BOARD_DATE;
	}
	public void setBOARD_DATE(Date bOARD_DATE) {
		BOARD_DATE = bOARD_DATE;
	}
	public int getBOARD_LIKE() {
		return BOARD_LIKE;
	}
	public void setBOARD_LIKE(int bOARD_LIKE) {
		BOARD_LIKE = bOARD_LIKE;
	}
	public int getBOARD_REPORT() {
		return BOARD_REPORT;
	}
	public void setBOARD_REPORT(int bOARD_REPORT) {
		BOARD_REPORT = bOARD_REPORT;
	}
	
	
}

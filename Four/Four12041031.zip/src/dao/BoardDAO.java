package dao;
import java.sql.*;
import java.util.ArrayList;
import vo.*;
import static db.JdbcUtil.*;
public class BoardDAO {
	private static BoardDAO boardDAO;
	private Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	private BoardDAO() {
		
	}
	public static BoardDAO getInstance() {
		if(boardDAO==null) {
			boardDAO = new BoardDAO();
		}
		return boardDAO;
	}
	public void setConnection(Connection con) {
		this.con=con;
	}
	public ArrayList<Board> boardList() {
		ArrayList<Board> boardList = new ArrayList<>();
		Board board = null;
		String sql = "select * from board order by board_num desc";
		try {
			pstmt = con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				board = new Board();
				board.setBOARD_NUM(rs.getInt("BOARD_NUM"));
				board.setBOARD_LINK(rs.getString("BOARD_LINK"));
				board.setBOARD_LINK_VIDEO(rs.getString("BOARD_LINK_VIDEO"));
				board.setBOARD_LINK_TITLE(rs.getString("BOARD_LINK_TITLE"));
				board.setBOARD_LINK_IMAGE(rs.getString("BOARD_LINK_IMAGE"));
				board.setBOARD_LINK_NAME(rs.getString("BOARD_LINK_NAME"));
				board.setBOARD_NAME(rs.getString("BOARD_NAME"));
				board.setBOARD_PASS(rs.getString("BOARD_PASS"));
				board.setBOARD_SUBJECT(rs.getString("BOARD_SUBJECT"));
				board.setBOARD_CONTENT(rs.getString("BOARD_CONTENT"));
				board.setBOARD_CATEGORY(rs.getString("BOARD_CATEGORY"));
				board.setBOARD_DATE(rs.getDate("BOARD_DATE"));
				board.setBOARD_LIKE(rs.getInt("BOARD_LIKE"));
				board.setBOARD_REPORT(rs.getInt("BOARD_REPORT"));
				boardList.add(board);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return boardList;
	}
	public int commentCount(int board_num) {
		String sql = "select count(*) from reboard where board_num=?";
		int result=0;
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, board_num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				result=rs.getInt(1);	
			}else {
				result=0;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return result;
	}
	public int boardCount() {
		String sql = "select count(*) from board";
		int result=0;
		try {
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				result=rs.getInt(1);	
			}else {
				result=0;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(pstmt);
		}
		return result+1;
	}
	public int boardWrite(Board board) {
		String sql = "insert into board values(?,?,?,?,?,?,?,?,?,?,?,SYSDATE,?,?)";
		int result=0;
		int num = boardCount();
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,num);
			pstmt.setString(2, board.getBOARD_LINK());
			pstmt.setString(3, board.getBOARD_LINK_VIDEO());
			pstmt.setString(4, board.getBOARD_LINK_TITLE());
			pstmt.setString(5, board.getBOARD_LINK_IMAGE());
			pstmt.setString(6, board.getBOARD_LINK_NAME());
			pstmt.setString(7, board.getBOARD_NAME());
			pstmt.setString(8, board.getBOARD_PASS());
			pstmt.setString(9, board.getBOARD_SUBJECT());
			pstmt.setString(10, board.getBOARD_CONTENT());
			pstmt.setString(11, "Category");
			pstmt.setInt(12, board.getBOARD_LIKE());
			pstmt.setInt(13, board.getBOARD_REPORT());
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		System.out.println(result);
		return result;
	}
	public boolean isVideoBoardWriter(int board_num, String parameter) {
		String board_sql = "select * from board where BOARD_NUM=?";
		boolean isWriter = false;

		try {
			pstmt = con.prepareStatement(board_sql);
			pstmt.setInt(1, board_num);
			rs = pstmt.executeQuery();
			rs.next();

			if (parameter.equals(rs.getString("BOARD_PASS"))) {
				isWriter = true;
			}
		} catch (SQLException ex) {
			System.out.println("isBoardWriter 에러 : " + ex);
		} finally {
			close(rs);
			close(pstmt);
		}

		return isWriter;
	}
	public void updateNum(int board_num) {
		String sql = "update board set board_num=board_num-1 where board_num>?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, board_num);
			pstmt.executeUpdate();
		}catch(Exception e) {
			
		}finally {
			close(pstmt);
		}
	}
	public int deleteVideo(int board_num) {
		PreparedStatement pstmt = null;
		String board_delete_sql = "delete from board where BOARD_NUM=?";
		int deleteCount = 0;

		try {
			pstmt = con.prepareStatement(board_delete_sql);
			pstmt.setInt(1, board_num);
			deleteCount = pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("boardDelete 에러 : " + ex);
		} finally {
			close(pstmt);
		}
		updateNum(board_num);
		return deleteCount;
	}
	
}
